<?php
class response{
    public $status = false;
    public $summary = None;
    public $error = [];
    public $data = None;

}


