<?php /*a:2:{s:57:"E:\wamp64\www\tp5\application\index\view\index\index.html";i:1559662381;s:57:"E:\wamp64\www\tp5\application\index\view\public\base.html";i:1559662748;}*/ ?>
<!DOCTYPE html>

<head>
    
    <meta charset="UTF-8">
    <title>Title</title>

    <link rel="stylesheet" href="/tp5/public/static/CSS/commons.css">
    <link rel="stylesheet" href="/tp5/public/static/CSS/bootstrap.min.css">
    <script src="/tp5/public/static/JS/jquery-3.3.1.min.js"></script>
    <script src="/tp5/public/static/JS/bootstrap.js"></script>
    <script type="text/javascript" src="/tp5/public/static/dependent/FileAPI/FileAPI.min.js"></script>
    <script type="text/javascript" src="/tp5/public/static/dependent/Jcrop/jquery.Jcrop.min.js"></script>
    <link rel="stylesheet" href="/tp5/public/static/dependent/Jcrop/jquery.Jcrop.min.css" />

    <script type="text/javascript" src="/tp5/public/static/dist/Jquery.ImageCropUpload1.js"></script>

    
<script>
    function gwc(nid) {
        $.ajax({
            url: "<?php echo url('index/index/gwc'); ?>",
            data: {id:nid},
            type: "post",
            success: function (data) {
                if(!data.status){
                    $('#LoginModal').modal('show')
                }

            }
        })

    }
</script>

    <script>
        $(function () {

            bindSendMsgEvent();
            bindRegisterEvent();
            bindLoginEvent();
            $(function(){
                $('#loginUserNc,#userOprBox').mouseover(function(){
                    $('#userOprBox').css('display', 'block');
                    $('#loginUserNc').addClass('active');
                }).mouseout(function () {
                    $('#userOprBox').css('display', 'none');
                    $('#loginUserNc').removeClass('active');
                })
            })
        });

        function ChangeCode(ths) {
            ths.src += "?";
        }
        function bindRegisterEvent(){
            $("#register").on('click', function () {
                $(".error-message").remove();
                $.ajax({
                    url: "<?php echo url('index/user/register'); ?>",
                    data: $("#register_form").serialize(),
                    type: "POST",
                    success: function (data) {
                        if(!data.status){
                            $.each(data.message,function (k,v) {
                                console.log(v);
                                var tag = document.createElement("span");
                                tag.className = "error-message";
                                tag.innerText=v;
                                $("#register_form input[name="+ k +"]").after(tag);
                            })
                        }else{
                            location.reload();
                        }

                    }
                })
            })
        }
        function bindSendMsgEvent() {
            $("#sendMsg").on('click',function () {
                $(".error-message").remove();
                var time =60;

                var ths= $(this);
                $.ajax({
                    url: "<?php echo url('index/user/sendmsg'); ?>",
                    type: "POST",
                    data: $('#email').serialize(),
                    success: function (data) {
                        if(data.status){
                            var interval = setInterval(function () {
                                ths.text("已发送"+ time +"");
                                time -= 1;
                                if(time <= 0){
                                    clearInterval(interval);
                                    ths.text("发送");
                                }
                            },1000)
                        }else {
                            var tag = document.createElement("span");
                            tag.className = "error-message";
                            tag.innerText = data.message;
                            $("#email").after(tag);
                        }



                    }
                })
            })
        }
        function bindLoginEvent(){
            $("#login").on("click", function () {
                $(".error-message").remove();
                $.ajax({
                    url: "<?php echo url('index/user/login'); ?>",
                    data: $("#login_form").serialize(),
                    type: "post",
                    success: function (data) {
                        if(!data.status){
                            alert(data.summary)
                            $.each(data.message,function (k,v) {
                                console.log(v);
                                var tag = document.createElement("span");
                                tag.className = "error-message";
                                tag.innerText=v;
                                $("#login_form input[name="+ k +"]").after(tag);
                            })
                        }else{
                            location.reload();
                        }
                    }

                })
            })
        }


    </script>


</head>
<body style="width:1200px;margin: 0 160px">

<nav  class="navbar navbar-default" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href='<?php echo url("index/index/index"); ?>'>网上商城</a>
            
        </div>
        <ul class="nav navbar-nav navbar-right">
            <?php if(app('session')->get('is_login')): ?>
            <li><a href="#" data-toggle="modal" data-target="#RegisterModal"><span class="glyphicon glyphicon-shopping-cart"></span> 购物车</a></li>
            <li><img src="<?php echo htmlentities($objjj['img']); ?>" width="40px" height="40px" style="margin-top: 5px" class="img-circle" alt=""></li>
            <li><a id="loginUserNc" href="#"><?php echo htmlentities(app('session')->get('username')); ?></a></li>
            <?php else: ?>
            <li><a href="#" data-toggle="modal" data-target="#RegisterModal"><span class="glyphicon glyphicon-user"></span> 注册</a></li>
            <li><a href="#" data-toggle="modal" data-target="#LoginModal"><span class="glyphicon glyphicon-log-in" ></span>登录</a></li>
            <?php endif; ?>

            <li> <form class="navbar-form navbar-left" role="search">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Search">
                </div>
                <button type="submit" class="btn btn-default">提交按钮</button>
            </form></li>
        </ul>
    </div>
</nav>







<div class="modal fade" id="RegisterModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel" align="center">用户注册</h4>
            </div>
            <div class="modal-body">
                <!-- 用户注册-->

                <form id="register_form" class="form-horizontal container" role="form">
                    <div class="form-group">
                        <label for="username" class="col-sm-2 control-label">用户名</label>
                        <div class="col-sm-10">
                            <input type="text" style="width: 20%;" class="form-control" id="username" name="username" placeholder="请输入用户名">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="col-sm-2 control-label">邮箱</label>
                        <div class="col-sm-10">
                            <input type="email" style="width: 20%;" class="form-control" name="email" id="email" placeholder="请输入邮箱">
                        </div>
                    </div>
                    <div class="form-group">
                        <label style="float: left;" for="email-code" class="col-sm-2 control-label">验证码</label>
                        <div class="col-sm-10">
                            <input type="text" style="width: 10%;float: left;" class="form-control" name="email-code" id="email-code" placeholder="请输入邮箱验证码">
                            <button style="float:left;margin-left: 10px;" type="button" class="btn btn-primary" id="sendMsg"> 发送
                            </button>
                        </div>


                    </div>
                    <div class="form-group">
                        <label for="password" class="col-sm-2 control-label">密码</label>
                        <div class="col-sm-10">
                            <input type="password" style="width: 20%;" class="form-control" id="password" name="password" placeholder="请输入密码">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox">请记住我
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="button" id="register" class="btn btn-default">注册</button>
                        </div>
                    </div>
                </form>



            </div>

        </div><!-- /.modal-content -->
    </div><!-- /.modal -->
</div>
<div class="modal fade" id="LoginModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: palegoldenrod">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel" align="center">登陆      </h4>
            </div>
            <div class="modal-body">
                <!-- 用户登陆-->
                <div class="form-group">
                    <h3 style="margin-left: 150px;" class="text-primary">username|email</h3>

                </div>
                <form id="login_form" class="form-horizontal container" role="form">
                    <div class="form-group">
                        <label for="username" class="col-sm-2 control-label">用户名</label>
                        <div class="col-sm-10">
                            <input type="text" style="width: 20%;" class="form-control" name="username" placeholder="请输入用户名">
                        </div>
                    </div>
                    <div class="form-group">
                        <label style="float: left;" for="email-code" class="col-sm-2 control-label">验证码</label>
                        <div class="col-sm-10">
                            <input type="text" style="width: 20%;float: left;" class="form-control" name="check-code" id="check-code" placeholder="请输入邮箱验证码">
                        </div>
                    </div>
                    <div class="form-group">
                        <label style="float: left;" for="email-code" class="col-sm-2 control-label"></label>
                        <div class="col-sm-10">
                            <img src="<?php echo captcha_src(); ?>" onclick="ChangeCode(this)" alt="captcha" height="70px" width="180px"/>
                        </div>


                    </div>
                    <div class="form-group">
                        <label for="password" class="col-sm-2 control-label">密码</label>
                        <div class="col-sm-10">
                            <input type="password" style="width: 20%;" class="form-control" name="password" placeholder="请输入密码">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox">请记住我
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="button" id="login" class="btn btn-default">登陆</button>
                        </div>
                    </div>
                </form>




            </div>

        </div><!-- /.modal-content -->
    </div><!-- /.modal -->
</div>



<div class="user-opr-box" id="userOprBox" style="left: 869px;">
    <a href="/user/link/saved/1" style="border-top:0;">我的新热榜</a>
    <a href="<?php echo url('index/user/edit'); ?>">设置</a>
    <a class="logout" href="<?php echo url('index/user/logout'); ?>">退出</a>
    <a href="http://www.chouti.com/c_45792645155" target="_blank" class="ie6-a">我的收藏</a>
</div>

<div id="myCarousel" class="carousel slide">
    <!-- 轮播（Carousel）指标 -->
    <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
    <!-- 轮播（Carousel）项目 -->
    <div class="carousel-inner">
        <div class="item active">
            <img src="/tp5/public/static/images/1500300._CB462711578_.jpg" alt="First slide">
        </div>
        <div class="item">
            <img src="/tp5/public/static/images/XCM_Manual1500300_2_190524._CB462807287_.jpg" alt="Second slide">
        </div>
        <div class="item">
            <img src="/tp5/public/static/images/zgn_20170518_1500300_ags4._CB508669197_.jpg" alt="Third slide">
        </div>
    </div>
    <!-- 轮播（Carousel）导航 -->
    <a class="carousel-control left" href="#myCarousel"
       data-slide="prev"> <span _ngcontent-c3="" aria-hidden="true" class="glyphicon glyphicon-chevron-right"></span></a>
    <a class="carousel-control right" href="#myCarousel"
       data-slide="next">&rsaquo;</a>
</div>
<?php if(is_array($book) || $book instanceof \think\Collection || $book instanceof \think\Paginator): $i = 0; $__LIST__ = $book;if( count($__LIST__)==0 ) : echo "$empty" ;else: foreach($__LIST__ as $key=>$b): $mod = ($i % 2 );++$i;?>
<div class="col-sm-6 col-md-3" style="height: 300px;width: 300px">
    <div class="thumbnail">
        <img src="<?php echo htmlentities($b['src']); ?>"
             alt="通用的占位符缩略图" width="32%" >
        <div class="caption">
            <h3 align="center"><?php echo htmlentities($b['name']); ?></h3>
            <p>价格：<?php echo htmlentities($b['price']); ?></p>
            <p>
                <a href="<?php echo url('index/shop'); ?>?id=<?php echo htmlentities($b['id']); ?>" class="btn btn-primary" role="button">
                    购买
                </a>
                <a onclick="gwc('{{$.id}}')" class="btn btn-default" role="button">
                    购物车
                </a>
            </p>
        </div>
    </div>
</div>
<?php endforeach; endif; else: echo "$empty" ;endif; ?>

</body>

</html>